from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.utils.datastructures import MultiValueDictKeyError
from django.contrib.sites.shortcuts import get_current_site
from .utils import generate_token
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from django.urls import reverse
from django.template.loader import render_to_string
from django.utils.encoding import force_bytes, force_str
from django.core.mail import EmailMessage
from django.conf import settings
from django.views import View
import threading
from django.contrib.auth.tokens import PasswordResetTokenGenerator
from .models import UserProfile, Item
from .forms import ItemForm

class EmailThread(threading.Thread):
    def __init__(self, email_message):
        self.email_message = email_message
        super().__init__()

    def run(self):
        self.email_message.send()

def cadastrar(request):
    if request.method == "POST":
        try:
            email = request.POST['email']
            password = request.POST['pass1']
            confirm_password = request.POST['pass2']
            telefone = request.POST['telefone']
            endereco = request.POST['endereco']
            cpf_cnpj = request.POST['cpf_cnpj']
        except MultiValueDictKeyError:
            messages.error(request, "Preencha todos os campos do formulário.")
            return render(request, 'auth/cadastrar.html')

        if password != confirm_password:
            messages.warning(request, "As senhas digitadas não correspondem!")
            return render(request, 'auth/cadastrar.html')

        if User.objects.filter(username=email).exists():
            messages.warning(request, "Este e-mail já existe")
            return render(request, 'auth/cadastrar.html')

        user = User.objects.create_user(username=email, email=email, password=password)
        user.is_active = False
        user.save()

        user_profile = UserProfile(user=user, telefone=telefone, endereco=endereco, cpf_cnpj=cpf_cnpj)
        user_profile.save()

        current_site = get_current_site(request)
        email_subject = "[Ative Sua Conta]"
        message = render_to_string('auth/activate.html', {
            'user': user,
            'domain': current_site.domain,
            'uid': urlsafe_base64_encode(force_bytes(user.pk)),
            'token': generate_token.make_token(user),
        })

        email_message = EmailMessage(email_subject, message, settings.EMAIL_HOST_USER, [email])
        EmailThread(email_message).start()

        messages.info(request, "Foi enviado um link em seu e-mail para ativação da sua conta.")
        return redirect('/lojaauth/login')
    return render(request, 'auth/cadastrar.html')

class ActivateContaView(View):
    def get(self, request, uidb64, token):
        try:
            uid = force_str(urlsafe_base64_decode(uidb64))
            user = User.objects.get(pk=uid)
        except (TypeError, ValueError, OverflowError, User.DoesNotExist):
            user = None
        
        if user is not None and generate_token.check_token(user, token):
            user.is_active = True
            user.save()
            messages.success(request, "Sua conta foi ativada com sucesso")
            return redirect('/lojaauth/login')
        else:
            messages.warning(request, "Link de ativação inválido")
            return render(request, "auth/activatefalha.html")

def handlelogin(request):
    if request.method == "POST":
        try:
            username = request.POST['email']
            userpassword = request.POST['pass1']
        except MultiValueDictKeyError:
            messages.error(request, "Preencha todos os campos do formulário.")
            return render(request, 'auth/login.html')
        
        myuser = authenticate(username=username, password=userpassword)

        if myuser is not None:
            login(request, myuser)
            messages.success(request, "Login feito com sucesso!")
            return render(request, 'index.html')
        else:
            messages.error(request, "Senha ou E-mail não correspondem!")
            return redirect('/lojaauth/login')
        
    return render(request, 'auth/login.html')

def handlelogout(request):
    logout(request)
    messages.success(request, "Saindo do sistema com sucesso")
    return redirect('/lojaauth/login')

class RequestResetEmailView(View):
    def get(self, request):
        return render(request, 'auth/request-reset-email.html')
    
    def post(self, request):
        email = request.POST['email']
        user = User.objects.filter(email=email)

        if user.exists():
            current_site = get_current_site(request)
            email_subject = '[Recupere Sua Senha]'
            message = render_to_string('auth/reset-user-password.html', {
                'user': user[0],
                'domain': current_site.domain,
                'uid': urlsafe_base64_encode(force_bytes(user[0].pk)),
                'token': PasswordResetTokenGenerator().make_token(user[0]),
            })

            email_message = EmailMessage(email_subject, message, settings.EMAIL_HOST_USER, [email])
            EmailThread(email_message).start()
            messages.info(request, "Um e-mail foi enviado com as instruções de como recuperar a sua senha.")
            return redirect('/lojaauth/login')
        
        messages.warning(request, "Este e-mail não está cadastrado")
        return render(request, 'auth/request-reset-email.html')

class SetNovaSenhaView(View):
    def get(self, request, uidb64, token):
        context = {
            'uidb64': uidb64,
            'token': token,
        }
        try:
            user_id = force_str(urlsafe_base64_decode(uidb64))
            user = User.objects.get(pk=user_id)
        
            if not PasswordResetTokenGenerator().check_token(user, token):
                messages.warning(request, "Link de redefinição de senha inválido")
                return redirect('/lojaauth/request-reset-email')
                
        except UnicodeDecodeError:
            messages.error(request, "Ocorreu um erro")
            return redirect('/lojaauth/request-reset-email')

        return render(request, 'auth/set-novo-password.html', context)

    def post(self, request, uidb64, token):
        context = {
            'uidb64': uidb64,
            'token': token,
        }

        password = request.POST['pass1']
        confirm_password = request.POST['pass2']
        if password != confirm_password:
            messages.warning(request, "Senha e confirmação não correspondem!")
            return render(request, 'auth/set-novo-password.html', context)

        try:
            user_id = force_str(urlsafe_base64_decode(uidb64))
            user = User.objects.get(pk=user_id)
            user.set_password(password)
            user.save()
            messages.success(request, "Senha recuperada com sucesso, faça seu login!")
            return redirect('/lojaauth/login')
        
        except UnicodeDecodeError:
            messages.error(request, "Ocorreu um erro")
            return render(request, 'auth/set-novo-password.html', context)

def catalogo(request):
    itens = Item.objects.all()
    return render(request, 'auth/catalogo.html', {'itens': itens})

def adicionar_item(request):
    if request.method == 'POST':
        form = ItemForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('catalogo')
    else:
        form = ItemForm()
    return render(request, 'adicionar_item.html', {'form': form})
