from django.apps import AppConfig

class LojaauthConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'lojaauth'

    def ready(self):
        import lojaauth.signals
