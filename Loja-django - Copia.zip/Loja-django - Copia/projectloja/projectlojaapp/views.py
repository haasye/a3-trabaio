from django.shortcuts import render
from django.shortcuts import render, redirect
from .forms import ItemForm
from django.contrib.auth.decorators import login_required
from .models import Item



def index(request):
    return render(request,'index.html')

def adicionar_item(request):
    if request.method == 'POST':
        form = ItemForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('catalogo')
    else:
        form = ItemForm()
    return render(request, 'adicionar_item.html', {'form': form})

def catalogo(request):
    items = Item.objects.all()
    return render(request, 'catalogo.html', {'items': items})
